import React, { Component } from 'react';

var backgroundImage = {
    width: "100%",
    height: "70vh",
    backgroundRepeat: 'no-repeat',
    backgroundImage: `url(${process.env.PUBLIC_URL + './image/background.jpg'})`,
    backgroundSize: 'cover',

  }
class Pricing extends Component {
    render() {
        return (
            <div>
                 <div className = 'price-slider' style = {backgroundImage}>
                     <div className = 'container'>
                         <div className = 'price-title text-center'>
                             <h1>Pricing</h1>
                             <p>Pricing We offer you the most profitable and reliable cloud mining contracts by,providing daily payouts for all the contracts in the currency of the contract. Start cryptocurrency and stablecoins cloud mining today, and get the first payout tomorrow!</p>
                             <button type="button" class="btn btn-primary bbtn mt-4">Start Mining Now</button>
                         </div>
                     </div>
                 </div>
            </div>
        );
    }
}

export default Pricing;